Following are the readme for the gmail label name extraction and sending the mail with the oauth athentication processes.

1.Create the google api in the google console 
    'https://console.cloud.google.com/apis/credentials/consent?project=sage-ripple-280814'
2.Activate the enable in the google cloud console
3.Create the credential in the application
4.OAuth is should have the publish app and install with the pip following
pip install --upgrade google-api-python-client google-auth-httplib2 google-auth-oauthlib
5.Finally we have to download the json file for the accessing our gmail or permission allowed to the gmail.

I task:
6.Print the label of the list from the email configuration

Following of the scopes is added for the operation in the OAuth
        .../auth/userinfo.email See your primary Google Account email address   
        .../auth/userinfo.profile   See your personal info, including any personal info you've made publicly available  
        openid  Associate you with your personal info on Google 
        Gmail API   .../auth/gmail.addons.current.action.compose    Manage drafts and send emails when you interact with the add-on 
        Gmail API   .../auth/gmail.addons.current.message.action    View your email messages when you interact with the add-on  
        Gmail API   .../auth/gmail.labels   See and edit your email labels

II task:
7.Sending the gmail to the address.
    Following of the scopes is added for the operation in the OAuth
        Gmail API   https://mail.google.com/    Read, compose, send, and permanently delete all your email from Gmail

    Following are the statement comes from their application try to click on the advance for sending the gmail.
        Google hasn’t verified this app
        The app is requesting access to sensitive info in your Google Account. Until the developer (jeyabalan360@gmail.com) verifies this app with Google, you shouldn't use it.

        If you’re the developer, submit a verification request to remove this screen. Learn more

        Advanced==>Hide Advanced
                    Continue only if you understand the risks and trust the developer (jeyabalan360@gmail.com).

                    Go to jeya (unsafe)

How to run the application:
      1.Go to the terminal
      2.Download the credential from the Oauth consent screen by creating the apps in the google developer mode.
      3.Run the created script with the virtual environement 
      (env) (jeya-cv) C:\220519-showroom_games_backup>pip install -r requirements.txt
      4.run python email-work.py

Following are the output output-link:
   I have attached the images of the following results.